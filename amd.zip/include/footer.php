<footer class="footer">
    <div class="containerFull">
        <p>© <?php echo date('Y'); ?> AMD Law. All rights reserved. <a href="/">Disclaimer</a> | <a href="/">Policy</a></p>
    </div>
</footer>